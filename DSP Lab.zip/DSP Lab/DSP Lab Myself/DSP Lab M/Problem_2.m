syms z n
a=1/16^n;
ZTrans=ztrans(a);       %Z transform
disp(ZTrans);
InvrZ=iztrans(ZTrans);       %InverseZtransform
disp(InvrZ);

B=[0 1 1];
A=[1 -2 3];
a=roots(A);
b=roots(B);
disp(a);
disp(b);
zplane(B,A);

clc;clear;
num=[1,0,0,1];
den=[1,0,2,0,1];
systf=tf(num,den);   %tf=transfer function
pzmap(systf);