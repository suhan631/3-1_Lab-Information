%Suppose our target is to pass all frequencies below f=1200 Hz
fs=8000; % sampling frequency
n=50;           % order of the filter
% w = f / (fs/2);
w=1200/ (fs/2);  %here w is cutoff frequency
b=fir1(n,w,'low'); % Zeros of the filter
% FREQZ(B,A,N,Fs)
freqz(b,1,128,fs); % Magnitude and Phase Plot of the filter
figure(2)
% [H,F] = FREQZ(B,A,N,Fs)
[h,w]=freqz(b,1,128,fs);
plot(w,abs(h)); % Normalized Magnitude Plot
grid
figure(3)
zplane(b,1);
