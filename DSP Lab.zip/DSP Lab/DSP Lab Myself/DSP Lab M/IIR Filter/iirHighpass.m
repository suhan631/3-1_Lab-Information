%We will consider same filter but our target now is to pass all frequencies above 1200 Hz
[n,w]=buttord(1200/5000,1500/5000,1,50);
[b,a]=butter(n,w,'high');
figure(1)
freqz(b,a,512,10000);
figure(2)
[h,q] = freqz(b,a,512,8000);
plot(q,abs(h)); % Normalized Magnitude plot
grid
figure(3)
f=1200:2:1500;
freqz(b,a,f,10000)
figure(4)
zplane(b,a)