#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define N 4 // Number of cities

int cost[N][N] = { // Distance matrix
    {0, 10, 15, 20},
    {10, 0, 35, 25},
    {15, 35, 0, 30},
    {20, 25, 30, 0}
};

int visited[N] = {0}; // Visited cities
int path[N + 1] = {0}; // Path of the salesman
int best_path[N + 1] = {0}; // Best path found so far
int min_cost = INT_MAX; // Minimum cost found so far

void tsp(int current_city, int current_cost, int current_depth) {
    if (current_depth == N) { // Base case
        if (current_cost + cost[current_city][0] < min_cost) {
            min_cost = current_cost + cost[current_city][0];
            for (int i = 0; i <= N; i++) {
                best_path[i] = path[i];
            }
        }
        return;
    }
    for (int i = 1; i < N; i++) {
        if (!visited[i]) { // If city i has not been visited
            visited[i] = 1;
            path[current_depth + 1] = i;
            tsp(i, current_cost + cost[current_city][i], current_depth + 1);
            visited[i] = 0;
        }
    }
}

int main() {
    visited[0] = 1; // Start at city 0
    path[0] = 0;
    tsp(0, 0, 0);
    printf("Best path: ");
    for (int i = 0; i <= N; i++) {
        printf("%d ", best_path[i]);
    }
    printf("\n");
    printf("Minimum cost: %d\n", min_cost);
    return 0;
}
